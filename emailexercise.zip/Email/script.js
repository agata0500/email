document.getElementById("emailForm").addEventListener("submit", function(event) {
    event.preventDefault();
    var emailInput = document.getElementById("emailInput");
    var message = document.getElementById("message");

    if (validateEmail(emailInput.value)) {
        message.textContent = "Thank you for subscribing!";
        message.style.color = "green";
        emailInput.value = "";
    } else {
        message.textContent = "Enter valid email address.";
        message.style.color = "red";
    }
});

function validateEmail(email) {
    var re = /\S+@\S+\.\S+/;
    return re.test(email);
}
